
#define MOTOR_HIGH 	128
#define MOTOR_LOW	128

#define M1_OCR_A	OCR4B
#define M1_OCR_B	OCR4C

#define M2_OCR_A	OCR3B
#define M2_OCR_B	OCR3C

void Step(dir);
