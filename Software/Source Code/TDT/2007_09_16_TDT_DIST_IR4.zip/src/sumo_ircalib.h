#ifndef __SUMOBOT_IRCALIBS_H__
#define __SUMOBOT_IRCALIBS_H__


const UBYTE ircalib_1_length = 19;

static USHORT ircalib_1[19][2] = {										
										{200,553},
										{300,432},
										{400,338},
										{500,264},
										{600,222},
										{700,191},
										{800,166},
										{900,147},
										{1000,131},
										{1100,118},
										{1200,108},
										{1300,99},
										{1400,94},
										{1500,89},
										{1600,83},
										{1700,71},
										{1800,72},
										{1900,69},
										{2000,69}
									   };


#endif //  __SUMOBOT_IRCALIBS_H__
