

void ioinit (void);
