// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//
#if !defined _STDAFX_H
#define _STDAFX_H

#include "standard.h"
#include "assert.h"

#endif //_STDAFX_H
