
#include "motor2.h"
#include "inttimer.h"
#include "sumo_ports.h"
#include "dotmatrix.h"
#include "pwm.h"
//#include "adpcm.h"
#include "data.h"
#include "sprites.h"


Motor leftMotor;
Motor rightMotor;
DotMatrix matrix;
PWM pwms;
IntTimer timer(0);
//ADPCM sound;

void updates()			//run state machines
{
	leftMotor.update();
	//rightMotor.update();
	matrix.update();
	//sound.update();
}

int main()
{
	Byte sprite[8] = {
						0b00000000,
						0b01100000,
						0b00111000,
						0b00111100,
						0b11111111,
						0b00111100,
						0b00111000,
						0b01100000,
					};
	Byte ball[3] = {
						0b01110000,
						0b10001000,
						0b01110000,
					};
	long lpos = 0;
	long lspeed = 0;
	long laccel = 0;
	Word i = 0;
	Byte temp = 0;
	Setup_Sumo_Ports();
	timer.setFrequency(4000);
	timer.setFunctionCall(updates);
	timer.start();
	leftMotor.setPhaseRegisters(&LEFT_PHASE_A, &LEFT_PHASE_B);
	rightMotor.setPhaseRegisters(&RIGHT_PHASE_A, &RIGHT_PHASE_B);
	//sound.setDataPointer(packed, sizeof(packed));
	//sound.fillBuffer();
	//sound.go();
	sei();	//let's start
	leftMotor.setTorque(128);
	rightMotor.setTorque(128);
	leftMotor.setTargetSpeed(4000);  //microsteps/tick - about 39 steps/second at 1kHz
	leftMotor.setAcceleration(5000);
	rightMotor.setTargetSpeed(4000);  //microsteps/tick - about 39 steps/second at 1kHz
	rightMotor.setAcceleration(5000);
	rightMotor.setFullStepping(GetSwitch(1));
	do
	{
		//sound.pumpBuffer();
	    leftMotor.setFullStepping(GetSwitch(1));
		rightMotor.setFullStepping(GetSwitch(1));
		lpos = leftMotor.getCurrentPosition();
		lspeed = leftMotor.getCurrentSpeed()>>8;
		laccel = leftMotor.getAcceleration();
		matrix.writeSprite(
				sc_hexDigits[(lspeed >> 4) & 0x0F],
				0,
				0,
				8,
				SPRITE_ALPHANUMERIC_HEIGHT
			);
			matrix.writeSprite(
				sc_hexDigits[lspeed & 0x0F],
				8,
				0,
				8,
				SPRITE_ALPHANUMERIC_HEIGHT
			);

		if (lspeed == leftMotor.getTargetSpeed()>>8)
		{
			leftMotor.setTargetSpeed(-(leftMotor.getTargetSpeed()));
		};
		//temp = (Byte)rand();
		//matrix.xorBit(temp, temp>>4);
/*
		matrix.setSprite(&ball[0], 0, 0, 5, 3);
		timer.waitMilliseconds(2000);
		for (i = 0; i<20; i++)
		{
			timer.waitMilliseconds(300);
			matrix.xorSprite(&ball[0], i, i, 5, 3);
			matrix.xorSprite(&ball[0], i+1, i+1, 5, 3);
		}
		for (i = 0; i<500; i++)
		{
			timer.waitMilliseconds(10);
			temp = (Byte)rand();
			matrix.xorBit(temp, temp>>4);
		}
		timer.waitMilliseconds(2000);
		matrix.clear();
		matrix.setSprite(&sprite[0], 0, 0, 8, 8);
		timer.waitMilliseconds(2000);
		for (i = 0; i<56; i++)
		{
			timer.waitMilliseconds((56-i)<<4);
			matrix.xorSprite(&sprite[0], i, 0, 8, 8);
			matrix.xorSprite(&sprite[0], i+1, 0, 8, 8);
		}
		timer.waitMilliseconds(2000);
		matrix.clear();
		matrix.xorSprite(&sprite[0], 8, 0, 8, 8);
		for (i = 0; i<56; i++)
		{
			timer.waitMilliseconds((56-i)<<4);
			matrix.xorSprite(&sprite[0], 8, i, 8, 8);
			matrix.xorSprite(&sprite[0], 8, i+1, 8, 8);
		}
		timer.waitMilliseconds(2000);
		matrix.clear();
*/
	}
	while (true);
	return int(0);
}
