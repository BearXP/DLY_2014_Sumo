#ifndef MOTOR_H
#define MOTOR_H
//includes
#include "standard.h"		//for standard types
#include <avr/io.h>			//for SREG
#include <avr/interrupt.h>	//for cli()
#include <stdlib.h>			//for abs()
#include "sin.h"			//for sin, cos


class Motor
{
public:
	Motor():
	torque(0),
	fullStepping(0),
	pos(0),
	speed(0),
	accel(0),
	targetSpeed(0)
	{
		initialize();
	}
	~Motor()
	{
	}
	void update()
	{
		updateMotor(pos, speed, accel, targetSpeed, torque, phaseAOut, phaseBOut, fullStepping);
	}
	long getCurrentSpeed()			//in microsteps/tick
	{
		long retSpeed;
		Byte sreg = SREG&0x80;
		cli();
		retSpeed = hiWord(speed);
		SREG |= sreg;
		return retSpeed;
	}
	long getTargetSpeed()
	{
		long retSpeed;
		Byte sreg = SREG&0x80;
		cli();
		retSpeed = hiWord(targetSpeed);
		SREG |= sreg;
		return retSpeed;
	}
	SWord getCurrentPosition()
	{
		SWord retPos;
		Byte sreg = SREG&0x80;
		cli();
		retPos = pos>>16;
		SREG |= sreg;
		return retPos;
	}
	void setTargetSpeed(long setSpeed)	//in microsteps/tick
	{
		Byte sreg = SREG&0x80;
		cli();
		targetSpeed = setSpeed<<16;
		if (speed < targetSpeed)
		{
			accel = abs(accel);
		} else
		{
			accel = -abs(accel);
		}
		SREG |= sreg;
	}
	void setFullStepping(bool stepType)	//in microsteps/tick
	{
		Byte sreg = SREG&0x80;
		cli();
		fullStepping = stepType;
		SREG |= sreg;
	}
	long getAcceleration()
	{
		return abs(accel);
	}
	void setAcceleration(long a)  //in picosteps/tick/tick
	{
		Byte sreg = SREG&0x80;
		cli();
		if (speed < targetSpeed)
		{
			accel = a;
		} else
		{
			accel = -a;
		}
		SREG |= sreg;
	}
	void setTorque(Byte t)
	{
		Byte sreg = SREG&0x80;
		cli();
		torque = t;
		SREG |= sreg;
	}
	void setPhaseRegisters(RegPointer a, RegPointer b)
	{
		Byte sreg = SREG&0x80;
		cli();
		phaseAOut = a;
		phaseBOut = b;
		SREG |= sreg;
	}
private:
	void initialize()
	{
	}
	RegPointer phaseAOut;		//pointer to PhaseA
	RegPointer phaseBOut;		//pointer to PhaseB
	Byte torque;		//torque 0-255
	bool fullStepping;	//full stepping
	long pos;			//current position in nanosteps
	long speed; 		//speed in picosteps/tick (256 picosteps = 1 nanostep, 256 nanosteps = 1 microstep, 256 microsteps = 1 step)
	long accel; 		//acceleration in picosteps/tick/tick
	long targetSpeed;	//target speed (picosteps)

	static Byte* m_bufferPointer;
	static inline void updateMotor(long &pos, long &speed,
	                               long accel,long targetSpeed, Byte torque,
								   RegPointer phaseAOut, RegPointer phaseBOut, bool fullStepping)
	{
		const Word FULL_PLUS = 254;
		const Byte HALFWAY = 128;
		long nextSpeed;
		Byte fullTorque;
		SDWord PhaseA, PhaseB;
		nextSpeed = speed + accel;
		if ((accel > 0) && (nextSpeed > targetSpeed))
		{
			speed = targetSpeed;
		} else if ((accel < 0) && (nextSpeed < targetSpeed))
		{
			speed = targetSpeed;
		} else
		{
			speed = nextSpeed;
		}
		pos += hiWord(speed);
		if (fullStepping)
		{
			fullTorque = hiByte(FULL_PLUS*(torque/2));
			if (sinByte[hiByte(loWord(pos))]>HALFWAY)
			{
				*phaseAOut = fullTorque+HALFWAY;
			} else
			{
				*phaseAOut = HALFWAY-fullTorque-1;
			}
			if (cosByte[hiByte(loWord(pos))]>HALFWAY)
			{
				*phaseBOut = fullTorque+HALFWAY;
			} else
			{
				*phaseBOut = HALFWAY-fullTorque-1;
			}
		} else  //microstepping
		{
			PhaseA = sinByte[hiByte(loWord(pos))]*2-255;
			PhaseA = (((PhaseA*torque)>>8)+255)/2;
			*phaseAOut = loByte(PhaseA);
			PhaseB = cosByte[hiByte(loWord(pos))]*2-255;
			PhaseB = (((PhaseB*torque)>>8)+255)/2;
			*phaseBOut = loByte(PhaseB);
		}
	}

};
#endif // MOTOR_H
