#ifndef __SUMOBOT_SPRITES_H__
#define __SUMOBOT_SPRITES_H__

enum //sprite constants
{ SPRITE_ALPHANUMERIC_WIDTH = 5,
  SPRITE_ALPHANUMERIC_HEIGHT = 7
};

static const Byte sc_sprite_0[] = {
	0b01110,
	0b10001,
	0b10001,
	0b10001,
	0b10001,
	0b10001,
	0b01110
};

static const Byte sc_sprite_1[] = {
	0b00100,
	0b01100,
	0b00100,
	0b00100,
	0b00100,
	0b00100,
	0b01110
};

static const Byte sc_sprite_2[] = {
	0b01110,
	0b10001,
	0b00010,
	0b00100,
	0b01000,
	0b10000,
	0b11111
};

static const Byte sc_sprite_3[] = {
	0b01110,
	0b10001,
	0b00001,
	0b00110,
	0b00001,
	0b10001,
	0b01110
};

static const Byte sc_sprite_4[] = {
	0b00010,
	0b00110,
	0b01010,
	0b10010,
	0b11111,
	0b00010,
	0b00010
};

static const Byte sc_sprite_5[] = {
	0b11111,
	0b10000,
	0b10000,
	0b11110,
	0b00001,
	0b10001,
	0b01110
};

static const Byte sc_sprite_6[] = {
	0b01110,
	0b10001,
	0b10000,
	0b11110,
	0b10001,
	0b10001,
	0b01110
};

static const Byte sc_sprite_7[] = {
	0b11111,
	0b00001,
	0b00010,
	0b00100,
	0b01000,
	0b10000,
	0b10000
};

static const Byte sc_sprite_8[] = {
	0b01110,
	0b10001,
	0b10001,
	0b01110,
	0b10001,
	0b10001,
	0b01110
};

static const Byte sc_sprite_9[] = {
	0b01110,
	0b10001,
	0b10001,
	0b01111,
	0b00001,
	0b10001,
	0b01110
};

static const Byte sc_sprite_A[] = {
	0b01110,
	0b10001,
	0b10001,
	0b11111,
	0b10001,
	0b10001,
	0b10001
};

static const Byte sc_sprite_B[] = {
	0b11110,
	0b10001,
	0b10001,
	0b11110,
	0b10001,
	0b10001,
	0b11110
};

static const Byte sc_sprite_C[] = {
	0b01110,
	0b10001,
	0b10000,
	0b10000,
	0b10000,
	0b10001,
	0b01110
};

static const Byte sc_sprite_D[] = {
	0b11110,
	0b10001,
	0b10001,
	0b10001,
	0b10001,
	0b10001,
	0b11110
};

static const Byte sc_sprite_E[] = {
	0b11111,
	0b10000,
	0b10000,
	0b11111,
	0b10000,
	0b10000,
	0b11111
};

static const Byte sc_sprite_F[] = {
	0b11111,
	0b10000,
	0b10000,
	0b11111,
	0b10000,
	0b10000,
	0b10000
};

static const Byte sc_sprite_X[] = {
	0b10001,
	0b10001,
	0b01010,
	0b00100,
	0b01010,
	0b10001,
	0b10001
};

static const Byte* sc_hexDigits[16] = {
	sc_sprite_0, sc_sprite_1, sc_sprite_2, sc_sprite_3,
	sc_sprite_4, sc_sprite_5, sc_sprite_6, sc_sprite_7,
	sc_sprite_8, sc_sprite_9, sc_sprite_A, sc_sprite_B,
	sc_sprite_C, sc_sprite_D, sc_sprite_E, sc_sprite_F
};

#endif // __SUMOBOT_SPRITES_H__
