/* This source file is part of the ATMEL AT32UC3-SoftwareLibrary-1.0.0 Release */

/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief ADC example driver for AVR32 UC3.
 *
 * This file provides an example for the ADC on AVR32 UC3 devices.
 *
 * - Compiler:           IAR EWAVR32 and GNU GCC for AVR32
 * - Supported devices:  All AVR32 devices with an ADC
 * - AppNote:
 *
 * \author               Atmel Corporation: http://www.atmel.com \n
 *                       Support email: avr32@atmel.com
 *
 *****************************************************************************/

/* Copyright (c) 2007, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*! \mainpage
 * \section intro Introduction
 * This is the documentation for the data structures, functions, variables, defines, enums, and
 * typedefs for the ADC driver. <BR>It also gives an example of the usage of the
 * ADC module, eg: <BR>
 * - Use the adjustable resistor and see the value on USART_1.
 * - Use the light sensor and see the value on USART_1.
 * - Use the temperature sensor and see the value on USART_1.<BR>
 * 
 * \section files Main Files
 * - adc.c : ADC driver
 * - adc.h : ADC header file
 * - adc_example.c : ADC code example
 *
 * \section compinfo Compilation Info
 * This software was written for the GNU GCC for AVR32 and IAR Systems compiler
 * for AVR32. Other compilers may or may not work.
 *
 * \section deviceinfo Device Info
 * All AVR32 devices with a ADC module can be used. This example has been tested
 * with the following setup:<BR>
 * - EVK1100 evaluation kit
 *
 * \section setupinfo Setup Information
 * <BR>CPU speed: <i> 12 MHz </i>
 * - Connect USART_1 to your serial port via a standard RS-232 D-SUB9 cable
 * - Set the following settings in your terminal of choice: 57600 8N1
 *
 * \section contactinfo Contact Information
 * For further information, visit
 * <A href="http://www.atmel.com/products/AVR32/">Atmel AVR32</A>.\n
 * Support e-mail address: avr32@atmel.com.
 */

#include "board.h"
#include "print_funcs.h"
#include "gpio.h"
#include "pm.h"
#include "adc.h"

/*!
 * \brief main function : do init and loop to display ADC values
 */
int main(int argc, char **argv)
{
  volatile avr32_adc_t * adc= (volatile avr32_adc_t *) &AVR32_ADC; // ADC register address

  signed short adc_value_1 = -1;
  signed short adc_value_2 = -1;
  signed short adc_value_3 = -1;

  unsigned short adc_channel_1 = 0;
  unsigned short adc_channel_2 = 1;
  unsigned short adc_channel_3 = 2;

  int i;

  // switch to oscillator 0
  pm_switch_to_osc0(&AVR32_PM, FOSC0, OSC0_STARTUP);

  // init debug serial line
  init_dbg_rs232(FOSC0);

  // enable GPIO pins for ADC module
  gpio_enable_module_pin(AVR32_ADC_AD_0_PIN,   AVR32_ADC_AD_0_FUNCTION);   // ADC channel 0
  gpio_enable_module_pin(AVR32_ADC_AD_1_PIN,   AVR32_ADC_AD_1_FUNCTION);   // ADC channel 1
  gpio_enable_module_pin(AVR32_ADC_AD_2_PIN,   AVR32_ADC_AD_2_FUNCTION);   // ADC channel 2

  // configure ADC
  adc_configure(adc);

  // enable channels
  adc_enable(adc,adc_channel_1);
  adc_enable(adc,adc_channel_2);
  adc_enable(adc,adc_channel_3);

  // do a loop
  for (;;)
  {
    // slow down operations
    for ( i=0 ; i < 1000000 ; i++);

    // display a header to user
    print_dbg("\x1B[2J\x1B[H\r\nADC Example\r\n");

    // start conversion
    adc_start(adc);

    // get value for first adc channel
    adc_value_1 = adc_get_value(adc, adc_channel_1);
    // display value to user
    print_dbg("HEX Value for Channel 1 : 0x");
    print_dbg_hex(adc_value_1);
    print_dbg("\r\n");

    // get value for second adc channel
    adc_value_2 = adc_get_value(adc, adc_channel_2);
    // display value to user
    print_dbg("HEX Value for Channel 2 : 0x");
    print_dbg_hex(adc_value_2);
    print_dbg("\r\n");

    // get value for third adc channel
    adc_value_3 = adc_get_value(adc, adc_channel_3);
    // display value to user
    print_dbg("HEX Value for Channel 3 : 0x");
    print_dbg_hex(adc_value_3);
    print_dbg("\r\n");
  }
}
