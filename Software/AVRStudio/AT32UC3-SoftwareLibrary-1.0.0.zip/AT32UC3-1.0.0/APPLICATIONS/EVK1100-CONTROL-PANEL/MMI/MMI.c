/* This source file is part of the ATMEL AT32UC3-SoftwareLibrary-1.0.0 Release */

/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief Control Panel MMI module.
 *
 * - Compiler:           GNU GCC for AVR32
 * - Supported devices:  All AVR32 devices.
 *
 * \author               Atmel Corporation: http://www.atmel.com \n
 *                       Support email: avr32@atmel.com
 *
 *****************************************************************************/
 
/* Copyright (c) 2007, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */



#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

#include "board.h"

/* Scheduler include files. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"


#include "tracedump.h"

#include "supervisor.h"

#include "MMI.h"
#include "dip204.h"
#include "spi.h"
#include "gpio.h"

//_____ M A C R O S ________________________________________________________


//_____ D E F I N I T I O N S ______________________________________________
/*! number of chars per line */
#define MMI_LINE_LENGTH     20
/*! number of lines on display */
#define MMI_NB_LINE         4
/*! definition of the MMI queue size */
#define MMI_QUEUE_SIZE      MMI_NB_LINE
/*! this is the first line */
#define LINE_1              0x01
/*! this is the second line */
#define LINE_2              0x02
/*! this is the third line */
#define LINE_3              0x03
/*! this is the fourth line */
#define LINE_4              0x04
/*! Link date line to the first one */
#define DATE_LINE           LINE_1
/*! Link param line to the second one */
#define PARAM_LINE          LINE_2
/*! Link User Menu line to the third one */
#define USER_MENU_LINE      LINE_3
/*! Link User Mess line to the fourth one */
#define USER_MESS_LINE      LINE_4

/*! define the char used upon USB connection */
#define MMI_USB_CONNECTED      0xB7
/*! define the White space char */
#define MMI_SPACE              0x20

/*! number of items in USB host Menu */
#define MMI_USB_HOST_MENU_MAX_ITEM      4
/*! number of items in USB Device Menu */
#define MMI_USB_DEVICE_MENU_MAX_ITEM    1
/*! number of items in Idle Menu */
#define MMI_IDLE_MENU_MAX_ITEM          1

/*! Banner for ATMEL product */
#define ATMEL_BANNER                    "  ATMEL  AVR32 UC3  "

/*! definition of the User action function pointer */
typedef Bool (*pfUserAction) (void);

//_____ D E C L A R A T I O N S ____________________________________________
#if USB_DEVICE_FEATURE != ENABLED
/*! Function to do nothing */
Bool b_MMI_do_nothing( void );
#endif

#ifndef USB_ENABLE
/*! Function to do nothing */
Bool b_MMI_do_nothing( void );
#endif

#ifdef USB_ENABLE
/*! lines to display in USB Host menu */
const portCHAR * MMI_USBHostMenu[MMI_USB_HOST_MENU_MAX_ITEM] = {
"\x20 Copy Logs        \x10",
"\x11 Move Logs        \x10",
"\x11 Upload WEB Files \x10",
"\x11 Upload CFG Files \x20"
};

/*! lines to display in USB Host menu */
const portCHAR * MMI_USBHostActingMenu[MMI_USB_HOST_MENU_MAX_ITEM] = {
"Copying Logs        ",
"Moving Logs         ",
"Uploading WEB Files ",
"Uploading CFG Files "
};

/*! functions to call in USB Host menu */
pfUserAction pfUSBHostUserAction[MMI_USB_HOST_MENU_MAX_ITEM] = {
b_USBHostCopyLogs,
b_USBHostMoveLogs,
b_USBHostCopyWeb,
b_USBHostCopyCfg
};

#if USB_DEVICE_FEATURE == ENABLED
/*! lines to display in USB Device menu */
const portCHAR * MMI_USBDeviceMenu[MMI_USB_DEVICE_MENU_MAX_ITEM] = {
"USB Mass Storage    "
};
#endif

#endif

/*! lines to display in Idle menu */
const portCHAR * MMI_IdleMenu[MMI_IDLE_MENU_MAX_ITEM] = {
#ifdef USB_ENABLE
#if USB_DEVICE_FEATURE == ENABLED
"Press \xDF Mass Storage"
#endif
#else
ATMEL_BANNER
#endif
};

/*! functions to call in Idle menu */
pfUserAction pfIdleUserAction[MMI_IDLE_MENU_MAX_ITEM] = {
#ifdef USB_ENABLE
#if USB_DEVICE_FEATURE == ENABLED
b_supervisor_switch_to_maintenance_mode
#endif
#else
b_MMI_do_nothing
#endif
};

/*! memory image of the display */
portCHAR Line[MMI_NB_LINE][MMI_LINE_LENGTH + 1];

/*! pointer to the memory image of the param line */
portCHAR * ParamScreen = Line[PARAM_LINE - 1];
/*! pointer to the memory image of the date line */
portCHAR * DateScreen = Line[DATE_LINE - 1];
/*! pointer to the memory image of the User Menu line */
portCHAR * UserMenuScreen = Line[USER_MENU_LINE - 1];
/*! pointer to the memory image of the User Mess line */
portCHAR * UserMessScreen = Line[USER_MESS_LINE - 1];

/*! current MMI user menu to handle */
eUserMenu eCurrentUserMenu = eUserMenuIdle;

/*! current item in user menu */
portCHAR cMMI_USB_CurrentItem = 0;

/*! The handle of the queue of MMI. */
static xQueueHandle xMMIQueue = 0;

/*! The handle of the queue of SUPERVISOR. */
extern xQueueHandle xSUPERVISORQueue;

static void prvMMI_Init(); // Forward declaration

/*-----------------------------------------------------------*/
/*! \brief function used by DIP204 LCD
 *
 */
void delay_ms(unsigned short time_ms)
{
   vTaskDelay( (portTickType)time_ms );
}

/*! \brief Init MMI, for Man to Macine Interface management.
 *
 */
Bool bMMI_start( void )
{
unsigned short i;

  for (i = 0 ; i < MMI_NB_LINE ; i++)
  {
    memset(Line[i], MMI_SPACE, MMI_LINE_LENGTH);
    Line[i][MMI_LINE_LENGTH] = '\0';
  }

  xMMIQueue = xQueueCreate( MMI_QUEUE_SIZE, sizeof(portCHAR *) );

  if( 0 == xMMIQueue )
  {
     return pdFALSE;
  }

  // Init MMI
  prvMMI_Init();

  /* go to Idle state */
  vMMI_SetUserMenuMode(eUserMenuIdle, pdTRUE);
  vMMI_UserMessDisplay(ATMEL_BANNER);
  return pdTRUE;
}

/*! \brief display IP in Param space
 *
 *  \param IPAddress   Input. IP to display
 *
 */
void vMMI_DisplayIP(portCHAR * IPAddress)
{
unsigned short i = 0;
  // clear previous line but not the last char (we sould be connected)
  memset(UserMenuScreen, MMI_SPACE, MMI_LINE_LENGTH - 1);
  // set new value
  do
  {
    ParamScreen[i++] = *IPAddress++;
  }while (*IPAddress != '\0' || i >= 15);
  // Add the refresh need to the xMMIQueue.
  xQueueSend( xMMIQueue, (void *)&ParamScreen, 0 );
}


/*! \brief display USB connection status.
 *
 *  \param bConnected   Input. USB connection status.
 *
 */
void vMMI_DisplayUSBState(Bool bConnected)
{
  if (bConnected == pdTRUE)
  {
    ParamScreen[MMI_LINE_LENGTH - 1] = MMI_USB_CONNECTED;
  }
  else
  {
    ParamScreen[MMI_LINE_LENGTH - 1] = MMI_SPACE;
  }
  // Add the refresh need to the xMMIQueue.
  xQueueSend( xMMIQueue, (void *)&ParamScreen, 0 );
}


/*! \brief display Date in Date space
 *
 *  \param pcDateTime        Input. date to display
 *
 */
void vMMI_DisplayDateAndTime(portCHAR * pcDateTime)
{
  strcpy(DateScreen, pcDateTime);
  // Add the refresh need to the xMMIQueue.
  xQueueSend( xMMIQueue, (void *)&DateScreen, 0 );
}


/*! \brief Validate the current item in User Menu
 *
 *  \param UnderIT   Input. True if calling from IT
 *
 */
void vMMI_UserMenuValidateItem(Bool UnderIT)
{
#ifdef USB_ENABLE
  // HOST mode : we have something to do
  if (eCurrentUserMenu == eUserMenuUSBHost)
  {
    // caller is under IT
    if (UnderIT)
    {
      portENTER_CRITICAL();
      // Add the function need to the xSUPERVISORQueue.
      xQueueSendFromISR( xSUPERVISORQueue, (void *)&(pfUSBHostUserAction[(unsigned portCHAR)cMMI_USB_CurrentItem]), 0 );
      portEXIT_CRITICAL();
    }
    else
    {
      // Add the function need to the xSUPERVISORQueue.
      xQueueSend( xSUPERVISORQueue, (void *)&(pfUSBHostUserAction[(unsigned portCHAR)cMMI_USB_CurrentItem]), 0 );
    }
  }
  // Idle mode : we have something to do
  else if (eCurrentUserMenu == eUserMenuIdle)
#else
  // Idle mode : we have something to do
  if (eCurrentUserMenu == eUserMenuIdle)
#endif
  {
    // caller is under IT
    if (UnderIT)
    {
      portENTER_CRITICAL();
      // Add the function need to the xSUPERVISORQueue.
      xQueueSendFromISR( xSUPERVISORQueue, (void *)&(pfIdleUserAction[(unsigned portCHAR)cMMI_USB_CurrentItem]), 0);
      portEXIT_CRITICAL();
    }
    else
    {
      // Add the function need to the xSUPERVISORQueue.
      xQueueSend( xSUPERVISORQueue, (void *)&(pfIdleUserAction[(unsigned portCHAR)cMMI_USB_CurrentItem]), 0 );
    }
  }
  // other mode : nothing to do...
  else
  {
    return;
  }
}

/*! \brief set MMI current Menu
 *
 *  \param UserMenu           Input. User Menu to handle
 *  \param ResetCurrentState  Input. pdFALSE if no need to reset MMI current screen number
 *
 */
void vMMI_SetUserMenuMode(eUserMenu UserMenu, Bool ResetCurrentState)
{
  if (ResetCurrentState)
  {
    // reset the screen number to display
    cMMI_USB_CurrentItem = 0;
  }
#ifdef USB_ENABLE
  // HOST menu
  if (UserMenu == eUserMenuUSBHost)
  {
    // set current user menu
    eCurrentUserMenu = eUserMenuUSBHost;
    // prepare the line for the display
    strcpy(UserMenuScreen, MMI_USBHostMenu[(unsigned portCHAR)cMMI_USB_CurrentItem]);
  }
  // HOST Acting menu
  else if (UserMenu == eUserMenuUSBHostActing)
  {
    // set current user menu
    eCurrentUserMenu = eUserMenuUSBHostActing;
    // prepare the line for the display
    strcpy(UserMenuScreen, MMI_USBHostActingMenu[(unsigned portCHAR)cMMI_USB_CurrentItem]);
  }
  // DEVICE menu
#if USB_DEVICE_FEATURE == ENABLED
  else if (UserMenu == eUserMenuUSBDevice)
  {
    // set current user menu
    eCurrentUserMenu = eUserMenuUSBDevice;
    // prepare the line for the display
    strcpy(UserMenuScreen, MMI_USBDeviceMenu[(unsigned portCHAR)cMMI_USB_CurrentItem]);
  }
#endif
  // eUserMenuIdle or error : reset MMI
  else
#endif
  {
    // reset current user menu
    eCurrentUserMenu = eUserMenuIdle;
    // prepare the line for the display
    strcpy(UserMenuScreen, MMI_IdleMenu[(unsigned portCHAR)cMMI_USB_CurrentItem]);
  }
  // Add the refresh need to the xMMIQueue.
  xQueueSend( xMMIQueue, (void *)&UserMenuScreen, 0 );
}


/*! \brief display next screen in User Menu space
 *
 *  \param UnderIT   Input. True if calling from IT
 *
 */
void vMMI_UserMenuDisplayNextItem(Bool UnderIT)
{
#ifdef USB_ENABLE
  // HOST menu
  if (eCurrentUserMenu == eUserMenuUSBHost)
  {
    // set the value for the screen number to display
    cMMI_USB_CurrentItem = Min(cMMI_USB_CurrentItem + 1, MMI_USB_HOST_MENU_MAX_ITEM - 1);
    // prepare the line for the display
    strcpy(UserMenuScreen, MMI_USBHostMenu[(unsigned portCHAR)cMMI_USB_CurrentItem]);
  }
#if USB_DEVICE_FEATURE == ENABLED
  // DEVICE menu
  else if (eCurrentUserMenu == eUserMenuUSBDevice)
  {
    // set the value for the screen number to display
    cMMI_USB_CurrentItem = Min(cMMI_USB_CurrentItem + 1, MMI_USB_DEVICE_MENU_MAX_ITEM - 1);
    // prepare the line for the display
    strcpy(UserMenuScreen, MMI_USBDeviceMenu[(unsigned portCHAR)cMMI_USB_CurrentItem]);
  }
#endif
  // error
  else
#endif
  {
    return;
  }
#ifdef USB_ENABLE
  // caller is under IT
  if (UnderIT)
  {
    portENTER_CRITICAL();
    // Add the refresh need to the xMMIQueue.
    xQueueSendFromISR( xMMIQueue, (void *)&UserMenuScreen, 0 );
    portEXIT_CRITICAL();
  }
  else
  {
    // Add the refresh need to the xMMIQueue.
    xQueueSend( xMMIQueue, (void *)&UserMenuScreen, 0 );
  }
#endif
}


/*! \brief display previous screen in User Menu space
 *
 *  \param UnderIT   Input. True if calling from IT
 *
 */
void vMMI_UserMenuDisplayPreviousItem(Bool UnderIT)
{
#ifdef USB_ENABLE
  // HOST menu
  if (eCurrentUserMenu == eUserMenuUSBHost)
  {
    // set the value for the screen number to display
    cMMI_USB_CurrentItem = Max(cMMI_USB_CurrentItem - 1, 0);
    // prepare the line for the display
    strcpy(UserMenuScreen, MMI_USBHostMenu[(unsigned portCHAR)cMMI_USB_CurrentItem]);
  }
  // DEVICE menu
#if USB_DEVICE_FEATURE == ENABLED
  else if (eCurrentUserMenu == eUserMenuUSBDevice)
  {
    // set the value for the screen number to display
    cMMI_USB_CurrentItem = Max(cMMI_USB_CurrentItem - 1, 0);
    // prepare the line for the display
    strcpy(UserMenuScreen, MMI_USBDeviceMenu[(unsigned portCHAR)cMMI_USB_CurrentItem]);
  }
#endif
  // error
  else
#endif
  {
    return;
  }
#ifdef USB_ENABLE
  // caller is under IT
  if (UnderIT)
  {
    portENTER_CRITICAL();
    // Add the refresh need to the xMMIQueue.
    xQueueSendFromISR( xMMIQueue, (void *)&UserMenuScreen, 0 );
    portEXIT_CRITICAL();
  }
  else
  {
    // Add the refresh need to the xMMIQueue.
    xQueueSend( xMMIQueue, (void *)&UserMenuScreen, 0 );
  }
#endif
}


/*! \brief display message in User Menu space
 *
 *  \param Message   Input. Message to display
 *
 */
void vMMI_UserMenuDisplay(portCHAR * Message)
{
unsigned short i = 0;

  // if MMI is ini IDLE state, display the message
  if (eCurrentUserMenu == eUserMenuIdle)
  {
    // add the received data to the line
    do
    {
      UserMenuScreen[i++] = *Message++;
    }while (*Message != '\0' && i < MMI_LINE_LENGTH);
    // fill in with white spaces to clear older data
    do
    {
      UserMenuScreen[i++] = MMI_SPACE;
    }while (i < MMI_LINE_LENGTH);
    // add EOL
    UserMenuScreen[MMI_LINE_LENGTH] = '\0';
     // Add the refresh need to the xMMIQueue.
    xQueueSend( xMMIQueue, (void *)&UserMenuScreen, 0 );
  }
}


/*! \brief display message in User Mess space
 *
 *  \param Message   Input. Message to display
 *
 */
void vMMI_UserMessDisplay(portCHAR * Message)
{
unsigned short i = 0;

  // add the received data to the line
  do
  {
    UserMessScreen[i++] = *Message++;
  }while (*Message != '\0' && i < MMI_LINE_LENGTH);
  // fill in with white spaces to clear older data
  do
  {
    UserMessScreen[i++] = MMI_SPACE;
  }while (i < MMI_LINE_LENGTH);
  // add EOL
  UserMessScreen[MMI_LINE_LENGTH] = '\0';
  // Add the refresh need to the xMMIQueue.
  xQueueSend( xMMIQueue, (void *)&UserMessScreen, 0 );
}


/*! \brief MMI function for Man to Macine Interface management.
 *
 */
void vMMI_Manage( void )
{
portCHAR * Line;

  // get queue information
  while ( pdTRUE == xQueueReceive( xMMIQueue, &Line, ( portTickType ) 0 ) )
  {
    // refresh line Param
    if (Line == ParamScreen)
    {
      taskENTER_CRITICAL();
      dip204_set_cursor_position(1,PARAM_LINE);
      dip204_write_string(ParamScreen);
      taskEXIT_CRITICAL();
    }
    // refresh line Date
    else if (Line == DateScreen)
    {
      taskENTER_CRITICAL();
      dip204_set_cursor_position(1,DATE_LINE);
      dip204_write_string(DateScreen);
      taskEXIT_CRITICAL();
    }
    // refresh line User Menu
    else if (Line == UserMenuScreen)
    {
      taskENTER_CRITICAL();
      dip204_set_cursor_position(1,USER_MENU_LINE);
      dip204_write_string(UserMenuScreen);
      taskEXIT_CRITICAL();
    }
    // refresh line User Mess
    else if (Line == UserMessScreen)
    {
      taskENTER_CRITICAL();
      dip204_set_cursor_position(1,USER_MESS_LINE);
      dip204_write_string(UserMessScreen);
      taskEXIT_CRITICAL();
    }
  }
}



/*! \brief MMI function for initialisation.
 *
 */
static void prvMMI_Init( void )
{
  spi_options_t spiOptions =
  {
    .reg          = DIP204_SPI_CS,
    .baudrate     = 400000,
    .bits         = 8,
    .spck_delay   = 0,
    .trans_delay  = 0,
    .stay_act     = 1,
    .spi_mode     = 3,
    .fdiv         = 0,
    .modfdis      = 1
  };

#if BOARD == EVK1100
#warning DIP204 and AT45DBX are sharing the same SPI
  // Only assign CS I/Os to SPI
  gpio_enable_module_pin(DIP204_SPI_NPCS_PIN,  DIP204_SPI_NPCS_FUNCTION); // Chip Select NPCS

#else
  // Assign I/Os to SPI
  gpio_enable_module_pin(DIP204_SPI_SCK_PIN,   DIP204_SPI_SCK_FUNCTION);   // SPI Clock
  gpio_enable_module_pin(DIP204_SPI_MISO_PIN,  DIP204_SPI_MISO_FUNCTION);  // MISO
  gpio_enable_module_pin(DIP204_SPI_MOSI_PIN,  DIP204_SPI_MOSI_FUNCTION);  // MOSI
  gpio_enable_module_pin(DIP204_SPI_NPCS_PIN,  DIP204_SPI_NPCS_FUNCTION);  // Chip Select NPCS

  // Initialise as master
  spi_initMaster(DIP204_SPI, &spiOptions);

  // Set selection mode: variable_ps, pcs_decode, delay
  spi_selectionMode(DIP204_SPI, 0, 0, 0);

  // Enable SPI
  spi_enable(DIP204_SPI);
#endif

  // setup chip registers
  spi_setupChipReg(DIP204_SPI, &spiOptions, CP_PBA_SPEED);

  /* initialise LCD */
  dip204_init( backlight_PWM ); // Use the PWM to control the LCD backlight pin.

  /* hide the cursor for the rest of application */
  dip204_hide_cursor();
}

/*! \brief function to do nothing upon user action
 *
 */
Bool b_MMI_do_nothing( void )
{
  NAKED_TRACE_COM2( "Nothing to do for this action" );
  return (pdTRUE);
}
