/* This source file is part of the ATMEL AT32UC3-SoftwareLibrary-1.0.0 Release */

/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief Control Panel USART driver module.
 *
 * - Compiler:           GNU GCC for AVR32
 * - Supported devices:  All AVR32 devices.
 *
 * \author               Atmel Corporation: http://www.atmel.com \n
 *                       Support email: avr32@atmel.com
 *
 *****************************************************************************/
 
/* Copyright (c) 2007, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
  BASIC INTERRUPT DRIVEN SERIAL PORT DRIVER FOR USART.
*/

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

/* Demo application includes. */
#include "serial.h"
#if __GNUC__
#  include <avr32/io.h>
#elif __ICCAVR32__
#  include <avr32/iouc3a0512.h>
#else
#  error Unknown compiler
#endif
#include "board.h"
#include "gpio.h"

/*-----------------------------------------------------------*/

/* Constants to setup and access the USART. */
#define serINVALID_COMPORT_HANDLER        ( ( xComPortHandle ) 0 )
#define serINVALID_QUEUE                  ( ( xQueueHandle ) 0 )
#define serHANDLE                         ( ( xComPortHandle ) 1 )
#define serNO_BLOCK                       ( ( portTickType ) 0 )

/*
 * Usart private data.
 */
typedef struct usartPrivateData
{
	volatile avr32_usart_t  *usart;
        xQueueHandle xRxedChars;	/*< Queue used to hold received characters. */
	xQueueHandle xCharsForTx;	/*< Queue used to hold characters waiting to be transmitted. */
} xUsartPrivateData;

xUsartPrivateData xUsart0 = {&AVR32_USART0, NULL, NULL}; // Usart0 data.
xUsartPrivateData xUsart1 = {&AVR32_USART1, NULL, NULL}; // Usart1 data.

/*-----------------------------------------------------------*/

/* Queues used to hold received characters, and characters waiting to be
transmitted. */
/* static xQueueHandle xRxedChars;
static xQueueHandle xCharsForTx;
*/

/*-----------------------------------------------------------*/

/* Forward declaration. */
static int iprvSerialCreateQueues( unsigned portBASE_TYPE uxRxQueueLength,
        xQueueHandle *pxRxedChars, unsigned portBASE_TYPE uxTxQueueLength,
        xQueueHandle *pxCharsForTx );

/*-----------------------------------------------------------*/

__attribute__((__noinline__)) static portBASE_TYPE prvUSART_ISR_NonNakedBehaviour( xUsartPrivateData *pxUsart )
{
  /* Now we can declare the local variables. */
  signed portCHAR     cChar;
  portBASE_TYPE     xTaskWokenByTx = pdFALSE, xTaskWokenByRx = pdFALSE;
  unsigned portLONG     ulStatus;
  portBASE_TYPE retstatus;

  /* What caused the interrupt? */
  ulStatus = pxUsart->usart->csr & pxUsart->usart->imr;

  if (ulStatus & AVR32_USART_CSR_TXRDY_MASK)
  {
    /* The interrupt was caused by the THR becoming empty.  Are there any
       more characters to transmit? */
    /* Because FreeRTOS is not supposed to run with nested interrupts, put all OS
      calls in a critical section . */
    portENTER_CRITICAL();
    retstatus = xQueueReceiveFromISR(pxUsart->xCharsForTx, &cChar, &xTaskWokenByTx);
    portEXIT_CRITICAL();
    if (retstatus == pdTRUE)
    {
      /* A character was retrieved from the queue so can be sent to the
         THR now. */
      pxUsart->usart->thr = cChar;
    }
    else
    {
      /* Queue empty, nothing to send so turn off the Tx interrupt. */
      pxUsart->usart->idr = AVR32_USART_IDR_TXRDY_MASK;
    }
  }

  if (ulStatus & AVR32_USART_CSR_RXRDY_MASK)
  {
    /* The interrupt was caused by the receiver getting data. */
    cChar = pxUsart->usart->rhr; //TODO

    /* Because FreeRTOS is not supposed to run with nested interrupts, put all OS
      calls in a critical section . */
    portENTER_CRITICAL();
    retstatus = xQueueSendFromISR(pxUsart->xRxedChars, &cChar, pdFALSE);
    portEXIT_CRITICAL();
    if (retstatus)
    {
      xTaskWokenByRx = pdTRUE;
    }
  }

  /* The return value will be used by portEXIT_SWITCHING_ISR() to know if it
  should perform a vTaskSwitchContext(). */
  return ( xTaskWokenByTx || xTaskWokenByRx );
}


/*
 * USART0 interrupt service routine.
 */
__attribute__((__naked__)) static void vUSART0_ISR( void )
{

 /* This ISR can cause a context switch, so the first statement must be a
  call to the portENTER_SWITCHING_ISR() macro.  This must be BEFORE any
  variable declarations. */
  portENTER_SWITCHING_ISR();
  prvUSART_ISR_NonNakedBehaviour(&xUsart0);
 /* Exit the ISR.  If a task was woken by either a character being received
  or transmitted then a context switch will occur. */
  portEXIT_SWITCHING_ISR();
}

/*
 * USART1 interrupt service routine.
 */
__attribute__((__naked__)) static void vUSART1_ISR( void )
{

 /* This ISR can cause a context switch, so the first statement must be a
  call to the portENTER_SWITCHING_ISR() macro.  This must be BEFORE any
  variable declarations. */
  portENTER_SWITCHING_ISR();
  prvUSART_ISR_NonNakedBehaviour(&xUsart1);
 /* Exit the ISR.  If a task was woken by either a character being received
  or transmitted then a context switch will occur. */
  portEXIT_SWITCHING_ISR();
}
/*-----------------------------------------------------------*/

/*!
 * \brief Init the serial port.
 * \param UsartId The identifier of the Usart to init.
 * \param ulWantedBaud The required baudrate.
 * \param uxRxQueueLength The length of the Rx buffer (if 0, rx is not supported).
 * \param uxTxQueueLength The length of the Tx buffer (if 0, tx is not supported).
 * \return xComPortHandle Handler on the COM port.
 */
xComPortHandle xUsartInit( eCOMPort UsartId, unsigned portLONG ulWantedBaud,
                           unsigned portBASE_TYPE uxRxQueueLength,
                           unsigned portBASE_TYPE uxTxQueueLength)
{
  xComPortHandle    xReturn;
  xUsartPrivateData *pxUsart;
  int               cd; /* USART Clock Divider. */
  int               UsartRxEnMask = ((uxRxQueueLength==0) ? 0 : AVR32_USART_CR_RXEN_MASK);
  int               UsartTxEnMask = ((uxTxQueueLength==0) ? 0 : AVR32_USART_CR_TXEN_MASK);
  int               iTempoStatus;

  xReturn = pxUsart = (UsartId == serCOM1 ? &xUsart0 : &xUsart1);

  /* Create the rx and tx queues. */
  iTempoStatus =  iprvSerialCreateQueues( uxRxQueueLength, &(pxUsart->xRxedChars),
                          uxTxQueueLength, &(pxUsart->xCharsForTx) );

  /* Configure USART. */
  if( ( iTempoStatus != pdFAIL ) &&
      ( ulWantedBaud != ( unsigned portLONG ) 0 ) )
  {
    portENTER_CRITICAL();
    {
      /**
       ** Reset USART.
       **/
      /* Disable all USART interrupt sources to begin... */
      pxUsart->usart->idr = 0xFFFFFFFF;

      /* Reset mode and other registers that could cause unpredictable
         behaviour after reset */
      pxUsart->usart->mr = 0; /* Reset Mode register. */
      pxUsart->usart->rtor = 0; /* Reset Receiver Time-out register. */
      pxUsart->usart->ttgr = 0; /* Reset Transmitter Timeguard register. */

      /* Shutdown RX and TX, reset status bits, reset iterations in CSR, reset NACK
         and turn off DTR and RTS */
      pxUsart->usart->cr = AVR32_USART_CR_RSTRX_MASK   |
                   AVR32_USART_CR_RSTTX_MASK   |
                   AVR32_USART_CR_RXDIS_MASK   |
                   AVR32_USART_CR_TXDIS_MASK   |
                   AVR32_USART_CR_RSTSTA_MASK  |
                   AVR32_USART_CR_RSTIT_MASK   |
                   AVR32_USART_CR_RSTNACK_MASK |
                   AVR32_USART_CR_DTRDIS_MASK  |
                   AVR32_USART_CR_RTSDIS_MASK;

      /**
       ** Configure USART.
       **/
      /* Enable USART RXD & TXD pins. */
      if(UsartId == serCOM1)
      {
        if(uxRxQueueLength)
          gpio_enable_module_pin(AVR32_USART0_RXD_0_PIN, AVR32_USART0_RXD_0_FUNCTION);
        if(uxTxQueueLength)
          gpio_enable_module_pin(AVR32_USART0_TXD_0_PIN, AVR32_USART0_TXD_0_FUNCTION);
      }
      else
      {
        if(uxRxQueueLength)
          gpio_enable_module_pin(AVR32_USART1_RXD_0_PIN, AVR32_USART1_RXD_0_FUNCTION);
        if(uxTxQueueLength)
          gpio_enable_module_pin(AVR32_USART1_TXD_0_PIN, AVR32_USART1_TXD_0_FUNCTION);
      }

      /* Set the USART baudrate to be as close as possible to the wanted baudrate. */
      /*
       *             ** BAUDRATE CALCULATION **
       *
       *                 Selected Clock                       Selected Clock
       *     baudrate = ----------------   or     baudrate = ----------------
       *                    16 x CD                              8 x CD
       *
       *       (with 16x oversampling)              (with 8x oversampling)
       */
      if ( ulWantedBaud < (CP_PBA_SPEED/16)  ){
        /* Use 8x oversampling */
        pxUsart->usart->mr |= (1<<AVR32_USART_MR_OVER_OFFSET);
        cd = CP_PBA_SPEED / (8*ulWantedBaud);

        if (cd < 2) {
          return serINVALID_COMPORT_HANDLER;
        }
        pxUsart->usart->brgr = (cd << AVR32_USART_BRGR_CD_OFFSET);
      } else {
        /* Use 16x oversampling */
        pxUsart->usart->mr &= ~(1<<AVR32_USART_MR_OVER_OFFSET);
        cd =  CP_PBA_SPEED / (16*ulWantedBaud);

        if (cd > 65535) {
          /* Baudrate is too low */
          return serINVALID_COMPORT_HANDLER;
        }
      }
      pxUsart->usart->brgr = (cd << AVR32_USART_BRGR_CD_OFFSET);

      /* Set the USART Mode register: Mode=Normal(0), Clk selection=MCK(0),
         CHRL=8,  SYNC=0(asynchronous), PAR=None, NBSTOP=1, CHMODE=0, MSBF=0,
         MODE9=0, CKLO=0, OVER(previously done when setting the baudrate),
         other fields not used in this mode. */
      pxUsart->usart->mr |= ((8-5) << AVR32_USART_MR_CHRL_OFFSET  ) |
                    (   4  << AVR32_USART_MR_PAR_OFFSET   ) |
                    (   1  << AVR32_USART_MR_NBSTOP_OFFSET);

      /* Write the Transmit Timeguard Register */
      pxUsart->usart->ttgr = 0;

      // Register the USART interrupt handler to the interrupt controller and
      // enable the USART interrupt.
      if(UsartId == serCOM1)
      	INTC_register_interrupt(&vUSART0_ISR, AVR32_USART0_IRQ, INT1);
      else
      	INTC_register_interrupt(&vUSART1_ISR, AVR32_USART1_IRQ, INT1);

      /* Enable USART interrupt sources (but not Tx for now)... */
      if(uxRxQueueLength)
        pxUsart->usart->ier = AVR32_USART_IER_RXRDY_MASK;

      /* Enable receiver and transmitter... */
      pxUsart->usart->cr |= UsartTxEnMask | UsartRxEnMask;
    }
    portEXIT_CRITICAL();
  }
  else
  {
    xReturn = serINVALID_COMPORT_HANDLER;
  }

  return xReturn;
}


/*-----------------------------------------------------------*/

/*!
 * \brief Get char from Usart.
 * \param pxPort The Usart handle to get the char from
 * \param pcRxedChar The rxed char(output)
 * \param xBlockTime The max time to wait for a rxed char
 */
signed portBASE_TYPE xUsartGetChar( xComPortHandle pxPort, signed portCHAR *pcRxedChar, portTickType xBlockTime )
{
  xUsartPrivateData *pxUsart = (xUsartPrivateData *)pxPort;

  /* Get the next character from the buffer.  Return false if no characters
  are available, or arrive before xBlockTime expires. */
  if( xQueueReceive( pxUsart->xRxedChars, pcRxedChar, xBlockTime ) )
  {
    return pdTRUE;
  }
  else
  {
    return pdFALSE;
  }
}

/*-----------------------------------------------------------*/

/*!
 * \brief Put char to Usart.
 * \param pxPort The Usart handle to put the char to
 * \param cOutChar The char to transmit
 * \param xBlockTime The max time to wait for getting the right to transmit the char.
 */
signed portBASE_TYPE xUsartPutChar( xComPortHandle pxPort, signed portCHAR cOutChar, portTickType xBlockTime )
{
xUsartPrivateData *pxUsart = (xUsartPrivateData *)pxPort;

  /* Place the character in the queue of characters to be transmitted. */
  if( xQueueSend( pxUsart->xCharsForTx, &cOutChar, xBlockTime ) != pdPASS )
  {
    return pdFAIL;
  }

  /* Turn on the Tx interrupt so the ISR will remove the character from the
  queue and send it.   This does not need to be in a critical section as
  if the interrupt has already removed the character the next interrupt
  will simply turn off the Tx interrupt again. */
  pxUsart->usart->ier = (1 << AVR32_USART_IER_TXRDY_OFFSET);

  return pdPASS;
}

/*-----------------------------------------------------------*/

unsigned portSHORT usUsartPutString( xComPortHandle pxPort, const signed portCHAR * const pcString, unsigned portSHORT usStringLength )
{
signed portCHAR *pxNext;

  /* Send each character in the string, one at a time. */
  pxNext = ( signed portCHAR * ) pcString;
  do
  {
    if(xUsartPutChar( pxPort, *pxNext, serNO_BLOCK ) != pdPASS)
      break; // The queue is full.
    pxNext++;
  } while( --usStringLength );

  return( usStringLength ); // Return the number of remaining characters.
}

/*-----------------------------------------------------------*/

void vSerialClose( xComPortHandle xPort )
{
  /* TODO? */
  /* Not supported as not required by the demo application. */
}
/*-----------------------------------------------------------*/

/*###########################################################*/

/*
 * Create the rx and tx queues.
 */
static int iprvSerialCreateQueues( unsigned portBASE_TYPE uxRxQueueLength, xQueueHandle *pxRxedChars,
                                    unsigned portBASE_TYPE uxTxQueueLength, xQueueHandle *pxCharsForTx )
{
  int iRet = pdPASS;

  /* Create the queues used to hold Rx and Tx characters. */
  // NOTE: xQueueCreate() will return NULL if the required length is 0.
  *pxRxedChars = xQueueCreate( uxRxQueueLength, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );
  *pxCharsForTx = xQueueCreate( uxTxQueueLength, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );
  if( ( ( uxRxQueueLength ) && (*pxRxedChars == NULL) ) ||
      ( ( uxTxQueueLength ) && (*pxCharsForTx == NULL) ) )
    iRet = pdFAIL;

  return(iRet);
}
/*-----------------------------------------------------------*/
